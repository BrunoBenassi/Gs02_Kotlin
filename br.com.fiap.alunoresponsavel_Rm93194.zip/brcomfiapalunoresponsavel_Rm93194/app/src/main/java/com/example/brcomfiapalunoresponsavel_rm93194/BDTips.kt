package com.example.brcomfiapalunoresponsavel_rm93194

data class BDTips (
    val descricao: String,
    val titulo: String,
     )

